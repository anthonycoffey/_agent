# Terraform — Agent VM on GCP

Fully automated infrastructure for the self-hosted AI agent stack described in
`self-hosted-ai-agent-guide.md`. Stands up a Compute Engine VM with Docker,
Tailscale, and the data+model foundation of the agent stack. You SSH in after
apply and layer on Open WebUI / n8n / Langfuse / MCP servers following the
main guide.

## What this creates

| Resource | Purpose |
|---|---|
| `google_compute_network` + subnet | Dedicated VPC, nothing else runs in it |
| `google_compute_firewall` (deny-all) | Default-deny ingress |
| `google_compute_firewall` (IAP SSH) | Optional fallback SSH via Identity-Aware Proxy |
| `google_compute_router_nat` | Outbound internet without a public IP on the VM |
| `google_service_account` + IAM | Narrow-scope SA attached to the VM |
| `google_compute_disk` | Boot disk with snapshot schedule attached |
| `google_compute_resource_policy` | Daily snapshots, 14-day retention |
| `google_compute_instance` | The VM itself, Shielded + OS Login |
| `google_storage_bucket` | Off-VM backup target with lifecycle rules |
| `random_password` × 7 | Secrets baked into the VM's `.env` on first boot |

## Prerequisites

1. **GCP project** with billing enabled. Create one:

   ```bash
   gcloud projects create YOUR-PROJECT-ID --name="Agent VM"
   gcloud billing projects link YOUR-PROJECT-ID --billing-account=XXXXXX-XXXXXX-XXXXXX
   gcloud config set project YOUR-PROJECT-ID
   gcloud auth application-default login
   ```

2. **Terraform** 1.9+.

3. **Tailscale** account + a pre-auth key:
   - Go to <https://login.tailscale.com/admin/settings/keys>
   - Generate: **reusable**, **ephemeral**, **pre-approved**, tagged `tag:agent`
   - Copy the key — you'll paste it into `terraform.tfvars`

4. **Declare the `tag:agent` tag** in your Tailnet ACL (Access Controls page):

   ```json
   {
     "tagOwners": {
       "tag:agent": ["autogroup:admin"]
     }
   }
   ```

## First-time setup

### Step 1 — Create the GCS state bucket

The backend bucket must exist before `terraform init`. Run:

```bash
./bootstrap/00-create-state-bucket.sh YOUR-PROJECT-ID YOUR-PROJECT-ID-tfstate-agent
```

### Step 2 — Point the backend at the bucket

Edit `backend.tf`:

```hcl
terraform {
  backend "gcs" {
    bucket = "YOUR-PROJECT-ID-tfstate-agent"
    prefix = "agent-vm"
  }
}
```

### Step 3 — Fill in variables

```bash
cp terraform.tfvars.example terraform.tfvars
$EDITOR terraform.tfvars
```

At minimum set:
- `project_id`
- `tailscale_auth_key`
- `timezone`
- `backup_bucket_suffix` (keep or change)

### Step 4 — Init + apply

```bash
terraform init
terraform plan
terraform apply
```

First apply takes ~3 minutes (API enablement + VM creation). cloud-init then
runs another ~5 minutes on the VM itself (package upgrades + Docker +
Tailscale join).

### Step 5 — Approve the node on Tailscale

Visit <https://login.tailscale.com/admin/machines>, find `agent-vm`, and
approve it if auto-approval isn't on for the `tag:agent` tag.

### Step 6 — SSH in

```bash
# Via Tailscale (preferred)
ssh agent@agent-vm

# Or fall back to IAP if Tailscale isn't up yet
gcloud compute ssh agent-vm --zone=us-central1-a --tunnel-through-iap
```

You'll see the welcome MOTD. At this point the VM is ready; the agent stack
isn't running yet because the first-boot API keys are blank. Fill them in:

```bash
cd ~/agent
$EDITOR .env   # set OPENAI_API_KEY / ANTHROPIC_API_KEY / GOOGLE_API_KEY
docker compose pull
docker compose up -d
docker compose ps
```

## Day-2 operations

### Update the VM

```bash
# Pull latest Ubuntu patches (unattended-upgrades also does this daily)
sudo apt update && sudo apt upgrade -y

# Pull latest images for the stack
cd ~/agent && docker compose pull && docker compose up -d
```

### Resize the VM

```bash
# Edit machine_type in terraform.tfvars, then:
terraform apply
# The VM will stop, resize, and start. allow_stopping_for_update = true
# in vm.tf permits this.
```

### Destroy everything

```bash
terraform destroy
```

The backup bucket has `force_destroy = false`, so Terraform will refuse to
delete it if it has objects. This is intentional — your backups are the last
line of defense. Empty it manually if you truly want it gone:

```bash
gcloud storage rm -r gs://YOUR-PROJECT-ID-agent-backups-01/**
terraform destroy
```

## What is NOT in Terraform (and why)

- **Application config for services you add post-bootstrap.** Open WebUI, n8n,
  Langfuse, Caddy, MCP servers — all live in `~/agent/docker-compose.yml`,
  versioned in your own git repo on the VM. Terraform is for infrastructure;
  Docker Compose is for services. Keeping them separate means a `docker compose
  up -d` doesn't re-plan the whole cloud.

- **Provider API keys.** Kept in `~/agent/.env` on the VM. If you want to move
  them into Secret Manager and have the VM pull them at container start,
  that's a nice second-pass exercise.

- **Tailnet ACL.** Declared in Tailscale's admin UI, not managed here. There's
  a `tailscale` Terraform provider if you want to change that.

## Secrets in state — is this safe?

Short answer: yes, for this use case.

Long answer: `random_password` values are persisted in plaintext inside the
Terraform state file. That state file lives in a GCS bucket with:

- `public_access_prevention = enforced`
- `uniform_bucket_level_access = true`
- IAM scoped to just you (plus whoever else you explicitly grant)
- Google-managed encryption at rest on every object

If that's not acceptable for your threat model, the options are:
1. Move secrets to Secret Manager, mark them `ephemeral` in Terraform (only
   read, never stored).
2. Use `terraform_remote_state` encryption with your own KMS key
   (`impersonate_service_account` + CMEK on the bucket).
3. Don't use `random_password`; bring your own and pass via `TF_VAR_*` env
   vars that never hit disk.

For a single-user personal stack on a project only you access, the default
posture is fine.

## Costs

Estimated monthly baseline (us-central1, on-demand):

| Item | Cost |
|---|---|
| `n2-standard-4` VM, 730 hrs | ~$140 |
| 200 GB pd-balanced boot disk | ~$20 |
| Daily snapshots (14-day retention, incremental) | ~$4 |
| Cloud NAT | ~$3 + $0.045/GB egress |
| GCS state + backup buckets | <$2 |
| **Subtotal** | **~$170** |

Model provider APIs are separate and depend on your usage.

## Files

```
.
├── README.md                        (this file)
├── versions.tf                      terraform + provider versions
├── backend.tf                       GCS state config
├── providers.tf                     provider + default_labels
├── variables.tf                     all inputs
├── iam.tf                           APIs, service account, IAM bindings
├── network.tf                       VPC, subnet, firewall
├── vm.tf                            disk, VM, NAT, secrets, cloud-init
├── backup.tf                        off-VM GCS backup bucket
├── outputs.tf                       post-apply info
├── terraform.tfvars.example         variable template
├── .gitignore
├── bootstrap/
│   └── 00-create-state-bucket.sh    one-time state-bucket creation
├── cloud-init/
│   └── agent-vm.yaml.tftpl          rendered into VM user-data
└── files/
    ├── docker-compose.yml           starter compose (data + model)
    ├── env.template                 .env reference
    ├── backup.sh                    nightly backup script
    └── motd                         SSH welcome banner
```
